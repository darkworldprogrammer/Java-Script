// // Function Declaration
// function mul(num) {
//   return num * num;
// }

// // Function Expression
// const mul = function (num) {
//   return num * num;
// };

// //  // Arrow function EXpression
// const mul = (num) => {
//   return num * num;
// };

//     OR
//  // Arrow function EXpression
const add = (a, b) => a + b;

// random value for OTP
const randomWord = () => Math.floor(Math.random()*10)+534982;
