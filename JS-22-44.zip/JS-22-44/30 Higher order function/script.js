function a() {
  // c();
  d();
}
function b() {}
function c() {
  console.log('Hii from function 3');
}
function d() {
  console.log('Hello from function 4');
}
a(b);
b(c);
b(d);

// -------------------------
function user1() {
  const Name = 'Himanshu';
  const Age = 22;
  const City = 'Bhopal';
  console.log(`Name = ${Name}`);
  console.log(`Age = ${Age}`);
  console.log(`City = ${City}`);
  // user2();
}
function user2() {
  const Name = 'Manish';
  const Age = 26;
  const City = 'New Delhi';
  // user3()
  console.log(`${user2}`);
}
function user3() {
  const Name = 'Beauty';
  const Age = 24;
  const City = 'Sasaram';
}
user1(user2);
user2(user3);

// ----------------->>>>>>>
// higher order function
function a(b) {
  console.log();
  b();
}
//callback function
function c() {
  console.dir('Hello');
}
a(c);
// ---------->>>>>>>>>>>>
// This is Higher order function
function a(b) {
  console.dir();
  b();
}
// this is callback function
a(function () {
  console.log('Hello');
});
