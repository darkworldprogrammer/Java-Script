// // passing arguments in a function
// const a = function args() {
//  for(let i=0;i<arguments.length;i++){
//   console.log(arguments[i]);
//   return i+(arguments.length)
//  }
// }
// console.log(a(1,2,3,4));

// finding sum of no.
const a = function args() {
  let sum=0;
  for (let i = 0; i < arguments.length; i++) {
    console.log(arguments[i]);
    sum +=arguments[i];
  }
  return sum;
};
console.log(a(1, 2, 3, 4));

const multi = function mul() {
  let mu=1;
  for(let i=0;i<arguments.length;i++){
    console.log(arguments[i]);
    mu *= arguments[i];
  }
  return mu;
}
console.log(multi(1,2,3));