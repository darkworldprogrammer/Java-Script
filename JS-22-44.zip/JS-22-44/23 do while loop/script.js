let i = 10;
do {
  console.log(i);
  i++;
} while (i < 5);
