function multiply(a, b) {
  return a * b;
}

// //  random no. using default parameter
// const randNo = function random(a = 10) {
//   // console.log(Math.random(a));
//   return Math.floor(Math.random() * a * 50600);
// };
// console.log(randNo(6));

// ----->>>>>>>>>

const ad = function randomNo(a = 3) {
  return Math.floor(Math.random(a) * a) + 1;
};
console.log(ad(554003));
