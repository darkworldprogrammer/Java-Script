// // // join both array using concatenation
const num1 = [1, 2, 3, 4, 5];
const num2 = [6, 7, 8, 9, 10];
// // console.log(num1.concat(num2));

// // // join using Spread Operator
const JoinedArray = [...num1, ...num2];
// const JoinedArray = [...num1, ...num2];
// console.log(JoinedArray);

// // ----->>>>>>>>

// const user1 = {
//   name: 'Himanshu',
//   age: '22',
//   city: 'Bhopal',
// };
// const user2 = { ...user1, Branch: 'CSE' };
// console.log(user2);

// // --------->>>>>>>>>>
// const add = function b() {
//   let sum = 0;
//   for (let i = 0; i < arguments.length; i++) {
//     // console.log(arguments[i]);
//     sum += arguments[i];
//   }
//   return sum;
// };
// // adding value of another array
// console.log(add(...JoinedArray));

// ------>>>>>>>>>>

// debugger
// finding average of any no.
const avg = function av() {
  let aver = 0;
  for (let i = 0; i < arguments.length; i++) {
    console.log(arguments[i]);
    aver += arguments[i];
  }
  console.log('Sum of arrays is: ' + aver);
  return 'Average of arrays is: ' + aver / arguments.length;
};
console.log(avg(...JoinedArray));
