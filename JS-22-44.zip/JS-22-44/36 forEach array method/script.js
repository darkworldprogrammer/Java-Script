// use strict key to check false value
'use strict';

const fruits = ['Mango', 'Banana', 'Apple', 'grapes'];
// const obj = {
//   name: 'Himanshu',
//   age: '22',
//   city: 'Bhopal',
// };

// ---------------->>>>>>>>>>
// print value by passing of parameter ass an argument
fruits.forEach(function (fruitsName) {
  console.log(fruitsName);
});
// -----------
console.log('*****************');
// passing by arrow function
var fruitsName = 'hello';
fruits.forEach((fruitsName) => {
  // console.log(fruitsName.toUpperCase());
  console.log(
    String(fruitsName).charAt(0).toUpperCase() + String(fruitsName).slice(1)
  );
  // console.log(fruitsName.toLowerCase());
  // return fruitsName
});

//  logic to create uppercase and lowercase
console.log('*****************');
console.log(
  Object(fruitsName).charAt(0).toUpperCase() +
    Object(fruitsName).charAt(1).toLowerCase() +
    Object(fruitsName).charAt(2).toUpperCase() +
    Object(fruitsName).charAt(3).toUpperCase() +
    Object(fruitsName).slice(4)
);
