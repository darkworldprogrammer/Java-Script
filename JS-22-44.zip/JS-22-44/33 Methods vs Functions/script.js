const maths = {
  E: 2.718281828459045,
  PI: 3.141592653589793,
  //  with functions
  add: function addi(a, b) {
    return a + b;
  },
  square: function mul(a) {
    return a ** 2;
  },
  subtract(a, b) {
    return a - b;
  },
  cube(a) {
    return a ** 3;
  },
};
console.dir(maths);
