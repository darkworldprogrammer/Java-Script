// // Function definition
// function myDetails(name) {
//   console.log(`Name = ${name}`);
//   console.log('Age = 22');
//   console.log('City = Bhopal');
//   return 'Thew Dark World';
// }
// //              Function calling
// // const display = myDetails();
// let userName = prompt('Enter Your Name') || 'The Dark World';
// myDetails(userName);

// -------------

// function intro(userName, userCity) {
//   console.log(`Name = ${userName}`);
//   console.log('Age = 22');
//   console.log(`City = ${userCity}`);
// }
// //              Function calling
// // const display = myDetails();
// let user1 = prompt('Enter Your Name') || 'The Dark World';
// let user2 = prompt('Enter Your City') || 'Kaimur';
// intro(user1, user2);

// ------------------
// user input their data

function userIntro(name, age, city, profession, hobby) {
  console.log('Hello');
  console.log(`i am ${name}`);
  console.log(`my age is ${age}`);
  console.log(`i am from ${city}`);
  console.log(`I am a ${profession}`);
  console.log(`My hobby is ${hobby}`);
}
let userName = prompt('Your Name: ');
let userAge = prompt('Your Age: ');
let userCity = prompt('Your City: ');
let userProfession = prompt('Your Profession: ');
let userHobby = prompt('Your Hobby: ');
userIntro(userName, userAge, userCity, userProfession, userHobby);
