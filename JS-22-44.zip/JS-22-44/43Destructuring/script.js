// destructuring array
const color = ['red', 'blue', 'pink', 'violet', 'yellow'];

const [color1, color2, color3] = color;
console.log(color1);
console.log(color2);
console.log(color3);
// --->>>>>>>>>>>>>>>>>>>

// now destructuring object
const user = {
  name: 'Himanshu Tiwari',
  age: 22,
  address: {
    city: 'Bhopal',
    state: 'india',
  },
};
const { name, age: userAge } = user;
// console.log(name);
// console.log(userAge);
// // --------------->>>>>>>>>>>>>
// // //  multilevel destructuring
const {
  address: { city, state },
} = user;
console.log(city);

// ------------------------------------->>>>>>>>
// // new method
// // for array:-------
// // we have to provide index value with their variable name
const { 2: color4 } = color;
console.log(color4);

//  // now destructuring the functions
function userIntro({ name, age }) {
  console.log(name);
  console.log(age);
}
userIntro(user);
//// -------->>>>>>>>>>>>
function printColors({ 2: thirdColor, 3: fourthColor }) {
  console.log(thirdColor);
  console.log(fourthColor);
}
printColors(color);
