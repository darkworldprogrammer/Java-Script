const numbers = [1, 2,3,4,5];
// numbers.reduce((accumulator,current,index) => {
// console.log(index,current);
// // console.log(index);
// },'initial Value');
// ------>>>>>>>>>>>>
// numbers.reduce((accumulator, current, index) => {
//   console.log(accumulator);
//   return current;
// }, 'accumulator');

// addition using accumulator
const addition = numbers.reduce((add,org,i)=>{
    // console.log(add,org);
    return  org +add;
},0)
console.log(addition);

// Multiplication
const n=[1,2,3,4,5];
const num = n.reduce((a,b)=>{
    console.log(b ,a);
    return (b*a)
})
console.log(num);