// map
// let a = ['hi', 'hello', 'welcome'];

// const hyy = a.map((sayHii) => {
//   console.log(sayHii);
//   return sayHii
// });

// const hyy = a.forEach((sayHii) => {
//   console.log(sayHii);
// });

// -------------->>>>>>>>>>>
// Filter

let months = ['january', 'february', 'March', 'april', 'May', 'December'];

// const filteredMonth = months.filter((month, i) => {
//   console.log(i, month.toUpperCase());
//   //  it only return when in return part in truthy value
//   // return month.length >= 3;
// });
// console.log(filteredMonth);

// ------>>>>>>.

// // check the month by their word
// const filteredMonth = months.filter((month) => {
//   console.log(month);
//   return month.toLowerCase().includes('m');
// });
// console.log(filteredMonth);

// ---------->>>>>>>>

// task to filter the adult students from data
const students = [
  {
    name: 'Himanshu',
    age: 22,
  },
  {
    name: 'Manish',
    age: 26,
  },
  {
    name: 'Beauty',
    age: 24,
  },
  {
    name: 'Anushka',
    age: 21,
  },
  {
    name: 'Bikas',
    age: 17,
  },
  {
    name: 'Mohit',
    age: 16,
  },
];
const adultStudent = students.filter((student) => {
  // console.log(student.age>=18);
  return student.age >= 18;
});
console.log(adultStudent);
//  filter only their names
const adultStudentName = adultStudent.map((filteredStudentName) => {
  return filteredStudentName.name;
});
console.log(adultStudentName);

const studentData = [
  {
    name: 'Devil',
    age: '22',
    city: 'Bhopal',
  },
  {
    name: 'Tiwari',
    age: '12',
    city: 'Bhopal',
  },
];
const filteredStudentData = studentData.filter((data, i) => {
  // console.log(data.age>=22);
  return data.age > 18;
});
console.log(filteredStudentData);

// Reduce----->>>>>>>>>
