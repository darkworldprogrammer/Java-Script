// const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
// // passing rest parameter inside the function name small braces
// const add = function n(...num) {
//   // console.log(num);
//   sum = 0;
//   for (let i = 0; i < num.length; i++) {
//     console.log(num[i]);
//     sum += num[i];
//   }
//   return 'sum of arrays: ' + sum;
// };
// console.log(add(...numbers));
// ------->>>>>>>>>>>>>>>>>>
// // passing rest parameter inside the function name small braces
// const add = function n(a, b, ...num) {
//   console.log(a, b);
//   console.log(num);
//   sum = 0;
//   for (let i = 0; i < num.length; i++) {
//     console.log(num[i]);
//     sum += num[i];
//   }
//   return 'sum of arrays: ' + sum;
// };
// console.log(add(...numbers));

// ------->>>>>>>>>>>>>>>>>>>>>>>>>
// const num = [1, 2, 3, 4, 5];
// let sum = 0;
// function a(...n) {
//   for (i = 0; i < n.length; i++) {
//     console.log(n[i]);
//     sum += n[i];
//   }
//   // return sum;
// }
// a(...num);
// console.log(`sum = ` + sum);

// ------->>>>>>>
// // adding numbers
// const num = {
//   a: [1, 2, 3, 4, 5],
//   b: [1, 2, 3, 4, 5],
// };
// function add(...nums) {
//   return nums.reduce((a, b) => a + b);
// }
// const result = add(...num.a, ...num.b);
// console.log(result);

// // ------>>>>>>>>>>>>>>>>>>>>>>

// const num = {
//   a: [1, 2, 3, 4, 5],
//   b: [1, 2, 3, 4, 5],
// };
// function add() {
//   return [...arguments].reduce((a, b) => a + b);
// };
// const res = add(...num.a, ...num.b);
// console.log(res);

// // ------>>>>>>>>>>>>>>>>>>>>>>
// // converting into array
const num = {
  a: [1, 2, 3, 4, 5],
  b: [1, 2, 3, 4, 5],
};
function add() {
  return Array.from(arguments).reduce((a, b) => a + b);
}
const res = add(...num.a, ...num.b);
console.log(res);
