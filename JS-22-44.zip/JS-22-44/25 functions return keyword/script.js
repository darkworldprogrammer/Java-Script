// // Addition
// function addition(a, b) {
//   return a + b;
// }
// const a = addition(8, 6);
// console.log(a);

// Subtraction
function subt(a, b) {
  return a - b;
}
const s = subt(2, 4);
console.log(s);
