// there is to scope
//  1. Global Scope
//      a. Window
//      b. Script
//  2. Local Scope
// --------------------
// Script Scope
const username = 'Himanshu';
const userAge = 22;
// Window scope
var City = 'Bhopal';
function add() {
  // Local Scopes
  const x = 5;
  const y = 8;
  console.log(x + y);
}
add();
console.log('Program ended');
