// // we can delay our code using setTimeout() function
// setTimeout(`console.log("Hello")
//   console.log("I am Himanshu")
//   ` ,1000);

// setTimeout(`console.log("Hello")
//   console.log("I am Himanshu")
//   ` ,1000);

// --------------------------
// const timer1 = setTimeout(`console.log("Hello delay 1s")`, 1000);
// const timer2 = setTimeout(`console.log("Hello delay 2s")`, 2000);
// const timer3 = setTimeout(`console.log("Hello delay 3s")`, 3000);
// // clearTimeout second
// clearTimeout(timer2);

// -----------------------

// using it with function
function a() {
  console.log(`Hello from function a()`);
}
setTimeout(a, 1000);

// set interval functiom
// setInterval()
// setInterval(a,1000)