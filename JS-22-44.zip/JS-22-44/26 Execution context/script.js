console.log('Program Started');
//function with parameter
function users(name, age, city) {
  console.log(`Name = ${name}`);
  console.log(`Age = ${age}`);
  console.log(`City = ${city}`);
  return 'Hello';
}
console.log(users('Himanshu', 22, 'Bhopal'));
// console.log(users());
console.log('Program Ended');

// Calculator function
function cal() {
  return {
    add: (a, b) => a + b,
    sub: (a, b) => a - b,
    mul: (a, b) => a * b,
    div: (a, b) => a / b,
  };
}
const calculate = cal();
console.log(calculate.add(3,3));
console.log(calculate.sub(3,3));
console.log(calculate.mul(3,3));
console.log(calculate.div(3,3));