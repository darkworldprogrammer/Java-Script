// use strict key to check false value
'use strict';

// const fruits = ['Mango', 'Banana', 'Apple'];
// // for of loop
// for (const fruit of fruits) {
//   console.log(fruit);
// }

// // using for of loop in string
// const user = 'Himanshu Tiwari';
// for (const later of user) {
//   console.log(later);
// }

// using for in loop in object
const obj = {
  Name: 'Himanshu Tiwari',
  Age: 22,
  City: 'Bhopal',
};
// for(const key in obj){
//     console.log(key , ': ' , obj[key]);
// }
// new method ---------------->>>>>>>>>>>>>>>>>>
const objectKey = Object.keys(obj);

for (const key of objectKey) {
  console.log(key, ':', obj[key]);
}
