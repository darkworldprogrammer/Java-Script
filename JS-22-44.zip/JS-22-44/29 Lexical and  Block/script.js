'use strict';
function myfunction() {
  const myfunction1 = 'Himanshu';
  console.log(myfunction1);
}
myfunction();
// num1=23

// Block scope
//  let
//  var
