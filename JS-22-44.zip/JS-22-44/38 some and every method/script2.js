//  by every function
const evenNo1 = [0, 2, 4, 6, 8, 10];
// ?checking the every no in array in EVEN
const result2 = evenNo1.every((num) => {
  return num % 2 == 0;
});
console.log(result2);

// =======>>>>>>>>
// ?checking the every no in array in EVEN
const result3 = evenNo1.every((num) => {
  return num % 2 == 1;
});
console.log(result3);
