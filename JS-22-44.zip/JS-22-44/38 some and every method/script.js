// by some function
const evenNo = [0, 2, 4, 6, 7, 8, 10];
// checking the index of odd no. from array
const result = evenNo.some((num, i) => {
  if (num % 2 == 1) {
    console.log('Odd no. at index : ' + i);
  }
  // return num % 2==1;
});

// finding the index of even no. from array
const oddNo = [1, 3, 5, 6, 7, 9, 11];
oddNo.some((odd, i) => {
  if (odd % 2 == 0) {
    console.log('Even no. Found at index: ' + i);
  }
});
