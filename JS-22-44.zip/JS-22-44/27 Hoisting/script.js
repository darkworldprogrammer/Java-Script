// declear using var is been hoist
//the built-in behavior of the language through which
//declarations of functions, variables, and classes are
// moved to the top of their scope – all before code execution.
console.log(username);
var username = 'Himanshu';
