// debugger
// // even number
// for (let i = 0; i <= 10; i++) {
//   if (i % 2 == 0) {
//     console.log(i);
//   }
// }

const user = [
  ['manish', 'Himanshu', 'Beauty', 'Satish'],
  ['Tiwary', 'Tiwari', 'Kumari', 'Tiwari'],
];
for (let i = 0; i <= user.length; i++) {
  console.log(`${user[i]}`);
}
