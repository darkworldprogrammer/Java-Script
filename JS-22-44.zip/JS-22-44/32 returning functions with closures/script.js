function parent() {
  // closure function are a and b(when we using outer functions
  // variable in inner function and return the inner function
  // in outer function is called Closure)
  const a = 4;
  const b = 5;
  function add() {
    console.log(a + b);
  }
  return add;
}
const c = parent();
console.dir(c);

// ----------------------
// function with inside the closures
function grandParent() {
  const a = 4;
  function parent() {
    const b = 7;
    function child() {
      const c = 9;
      console.log(a + b + c);
    }
    return child;
  }
  return parent();
}
const call = grandParent();
console.dir(call);