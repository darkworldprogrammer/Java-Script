//  // select tags and elements ----->>>>
document.getElementsByClassName('img')[1];
document.getElementsByTagName('img');
document.images;
document.getElementById('h1').innerText;
document.getElementsByClassName('html-img')[0];
// document.getElementsByClassName('html-img')[0].src =
//   'https://i0.wp.com/picjumbo.com/wp-content/uploads/beautiful-fall-nature-scenery-free-image.jpeg?w=600&quality=80';
document.getElementById('img1');

// // --------------->>>>>.
const htmlImg = document.querySelector('.html-img');
document.querySelector('#img1');
document.querySelectorAll('#img1')[0].src;
const htmlImg1 = document.querySelector('.html-img');

//  // -------->>>>>>>>
// //attribute selector
const cssImg = document.querySelector(`[alt='css image']`);
const cssImg1 = document.querySelectorAll(`[alt]`);
const li = document.querySelectorAll(`ul li`);
//  // ------>>>>>>>>>
// const add = document.querySelector('#h1');
// add.innerText = 'hyy';

// // change all images ------>>>>>>>>
const selectAllImg = document.querySelectorAll(`[alt]`);
// selectAllImg[0].src =
//   'https://cdn.pixabay.com/photo/2024/05/26/10/15/bird-8788491_640.jpg';
// selectAllImg[1].src =
//   'https://images.pexels.com/photos/417074/pexels-photo-417074.jpeg?cs=srgb&dl=pexels-souvenirpixels-417074.jpg&fm=jpg';
// selectAllImg[2].src = `https://t3.ftcdn.net/jpg/08/30/29/20/360_F_830292015_ygQp4THNtsi9RmhIlZwB0sn3IIdlYRis.jpg`;

// // //------->>>>>>>>>>>>>>>>>>>>>>>
// // //------->>>>>>>>>>>>>>>>>>>>>>>
//  // add images using for loop

const allImg = document.querySelectorAll('img');
const imgUrl = [
  `https://cdn.pixabay.com/photo/2024/05/26/10/15/bird-8788491_640.jpg`,
  `https://images.pexels.com/photos/417074/pexels-photo-417074.jpeg?cs=srgb&dl=pexels-souvenirpixels-417074.jpg&fm=jpg`,
  `https://t3.ftcdn.net/jpg/08/30/29/20/360_F_830292015_ygQp4THNtsi9RmhIlZwB0sn3IIdlYRis.jpg`,
];
// for (let i = 0; i < allImg.length; i++) {
//   allImg[i].src = imgUrl[i];
// }

//  // // =-------------=======>>>>
//  // // =-------------=======>>>>
// // // second method
allImg.forEach((img, i) => (img.src = imgUrl[i]));
