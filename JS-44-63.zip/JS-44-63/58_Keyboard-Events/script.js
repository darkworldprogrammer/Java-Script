const h1 = document.querySelector('h1');
const form = document.querySelector('form');
const input = document.querySelector('input');

// // // keypress event
// h1.addEventListener('keypress', (e) => {
//   console.log(e.key);
// });

// form.addEventListener('keypress', (e) => {
//   console.log('value:', e.key);
//   console.log('code:', e.code);
// });

// form.addEventListener('keyup', (e) => {
//   console.log('value:', e.key);
//   console.log('code:', e.code);
// });

form.addEventListener('keydown', (e) => {
  console.log('value:', e.key);
  console.log('code:', e.code);
});
