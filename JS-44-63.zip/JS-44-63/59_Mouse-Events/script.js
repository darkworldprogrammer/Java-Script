const body = document.querySelector('body');
const box = document.querySelector('.box');
// let count = 0;
// box.addEventListener('click', () => {
//   const newBox = box.cloneNode();
//   count++;
//   body.append(newBox);
// });

// // // mouse down event
// box.addEventListener('mousedown', () => {
//   const newBox = box.cloneNode();
//   body.append(newBox);
// });

// // // mouse up event
// box.addEventListener('mouseup', () => {
//   const newBox = box.cloneNode();
//   body.append(newBox);
// });

// // // mouse enter event
// box.addEventListener('mouseenter', () => {
//   const newBox = box.cloneNode();
//   body.append(newBox);
// });

// // // // mouse leave event
// box.addEventListener('mouseleave', () => {
//   const newBox = box.cloneNode();
//   body.append(newBox);
// });

// // // // mouse move event
// box.addEventListener('mousemove', () => {
//   const newBox = box.cloneNode();
//   body.append(newBox);
// });

// // // // mouse out event
// box.addEventListener('mouseout', () => {
//   const newBox = box.cloneNode();
//   body.append(newBox);
// });

// // // // mouse over event
// box.addEventListener('mouseover', () => {
//   const newBox = box.cloneNode();
//   body.append(newBox);
// });

// // // // wheel event (using two finger or mouse wheel)
// box.addEventListener('wheel', () => {
//   const newBox = box.cloneNode();
//   body.append(newBox);
// });

// // // // scroll event (using two finger or mouse wheel)
// box.addEventListener('scroll', () => {
//   const newBox = box.cloneNode();
//   body.append(newBox);
// });

// // // // touchstart event (only work on mobiles)
// box.addEventListener('touchstart', () => {
//   const newBox = box.cloneNode();
//   body.append(newBox);
// });

// // // // touchmove event (only work on mobiles)
// box.addEventListener('touchmove', () => {
//   const newBox = box.cloneNode();
//   body.append(newBox);
// });

// // // // drag event (only work on mobiles)
// box.addEventListener('drag', () => {
//   const newBox = box.cloneNode();
//   body.append(newBox);
// });

// // // // pointermove event (only work on mobiles)
// let n = 0;
// box.addEventListener('pointermove', (e) => {
//   const newBox = document.createElement('div');
//   newBox.className = 'box';
//   newBox.innerText = n++;
//   body.append(newBox);
// });

// // // // pointerenter event (only work on mobiles)
// let n = 0;
// box.addEventListener('pointerenter', (e) => {
//   const newBox = document.createElement('div');
//   newBox.className = 'box';
//   newBox.innerText = n++;
//   body.append(newBox);
// });

// // // pointerleave event (only work on mobiles)
let n = 0;
box.addEventListener('pointerleave', (e) => {
  const newBox = document.createElement('div');
  newBox.className = 'box';
  newBox.innerText = n++;
  body.append(newBox);
});
