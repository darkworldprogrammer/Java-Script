const images = document.querySelector('img');
const section = document.querySelector('#sec');

// // // ==============>>>>>>>
// // // ==============>>>>>>>
// // //adding many images when one img in html is available
// const fun = (a) => {
//   for (let i = 1; i <= 3; i++) {
//     let newImgs = images.cloneNode();
//     newImgs.src = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${i}.png`;
//     section.append(newImgs);
//   }
// };
// fun(section);

// // // ==============>>>>>>>
// //adding many images when no img available in html
// // //creating tags inside html using JS
const img = document.createElement('img');
const body = document.querySelector('body');

for (let i = 1; i <= 10; i++) {
  // updating the image source
  const imgSrc =
    (img.src = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${i}.png`);
  const am = img.cloneNode('');
  body.append(am);
}
