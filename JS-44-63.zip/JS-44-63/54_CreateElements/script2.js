// // creating many images tags and add images
// for (let i = 1; i <= 100; i++) {
//   const s = document.querySelector('#sec');
//   const d = document.createElement('div');
//   const img = document.createElement('img');
//   const p = document.createElement('p');

//   d.className = 'div';
//   img.src = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${i}.png`;
//   p.className = 'para';
//   p.innerText = i;
//   d.append(img, p);
//   s.append(d);
// }

// // // ==========>>>>>>>>>>>>>>>>>>>>>>>>>>>
// // // //another way to createElement
// const s = document.querySelector('#sec');
// for (let i = 1; i <= 10; i++) {
//   const d = document.createElement('div');
//   d.className = 'div';

//   const Html = `
//         <img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${i}.png" alt="">
//       <p class="para">${i}</p>
//   `;

//   d.innerHTML = Html;
//   s.append(d);
// }

//  /// third way to create html tags and elements
let section = document.querySelector('#sec');
let HTML = ``;
for (let i = 1; i <= 100; i++) {
  HTML += `
       <section id="sec">
      <div class="div">
        <img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${i}.png" alt="">
      <p class="para">${i}</p>
      </div>
    </section>
    `;
  section.innerHTML = HTML;
}
