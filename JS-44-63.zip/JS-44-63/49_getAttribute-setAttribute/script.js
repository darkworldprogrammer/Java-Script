const attributeSelect = document.querySelector(`[thedarkworld="himanshu"]`);
attributeSelect.innerText = 'hy';

// getAttribute property
document.querySelector('div').getAttribute('thedarkworld');
// document.querySelector('h1').getAttribute('class')

//  // ---------------->>>>>>>>>>>.
//  // ---------------->>>>>>>>>>>.
//  // setAttribute use to set attribute and value
document.querySelector('h1').setAttribute('title', 'HelloWorld');
document.querySelector('h1').getAttribute('title'); // access attribute by this
document.querySelector('h1').setAttribute('id', 'heading');
document.querySelector('h2').setAttribute('id', 'heading');
