// function sayhi() {
//   console.log('Hii');
// }

// // // // adding event listeners
// const parent = document.body;
// const a = 'Himanshu';
// function sayhi() {
//   if (a) {
//     parent.innerText = a;
//   }
// }

// // // adding event listeners
// const a = document.querySelector('.card');
// function sayhi() {
//   a.style.backgroundColor = 'blue';
// }
// a.onclick = sayhi;

// // // ===========>>>>>>>>
// function sayhii() {
//   a.style.backgroundColor = 'green';
// }
// a.ondblclick = sayhii;

// // // best method for eventListener
// // // best method for eventListener
// const a = document.querySelector('.card');
// function sayhi() {
//   a.style.backgroundColor = 'blue';
//   console.log('hy');
// }
// function userName() {
//   a.style.color = 'red';
//   console.log('hello');
// }
// a.addEventListener('click', sayhi, userName);
// a.addEventListener('click', userName);

// // //================>>>>>>>>>>>>>
// // //================>>>>>>>>>>>>>

let container = document.querySelector('.container');
let card = document.querySelector('.card');
const a = document.querySelector('.card');

// a.addEventListener('click', () => {
//   // creating new tag
//   let newCard = document.createElement('div');
//   newCard.textContent = '+';
//   newCard.className = 'card';
//   let createdCard = container.append(newCard);
// });

// // //================>>>>>>>>>>>>>
// // //================>>>>>>>>>>>>>
let count = 1;
a.addEventListener('click', () => {
  // cloning existing tag
  let oldClone = a.cloneNode();
  oldClone.textContent = count++;
  // count++;
  container.append(oldClone);
});
