// access element inside body
const h1 = document.body.children[0];
const h2 = document.body.children[1];
const span1 = document.body.children[2];
const span2 = document.body.children[3];
// // ================>>>>>>>>>
// // access the parent of paragraph
const p = document.querySelector('p');
const p_h1 = p.parentElement.previousElementSibling.previousElementSibling;
// // update the text element which is outside the tag
document.body.childNodes[4].textContent = 'Hello';
// ========== access this with JS
// <!-- without tag Element -->
// Himanshu Tiwari

document.body.childNodes[10].textContent = 'Welcome Himanshu';
