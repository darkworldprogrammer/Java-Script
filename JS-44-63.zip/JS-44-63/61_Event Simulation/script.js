const parent = document.querySelector('.parent');
const box = document.querySelector('.box');
const form = document.querySelector('form');
const input = document.querySelector('input');

// let n = 0;
// const cards = box.addEventListener('click', () => {
//   const newBox = document.createElement('div');
//   newBox.className = 'box';
//   newBox.innerText = n++;
//   parent.append(newBox);
// });

// const intervalId = setInterval(() => {
//   if (n > 10) {
//     clearInterval(intervalId);
//   }
//   box.click();
// }, 200);

// // // focus on input
// input.focus();

// // // //  setting timeout for focus
// setTimeout(() => {
//   input.focus();
// }, 1000);

// // // //  setting timeout for blur
// setTimeout(() => {
//   input.blur();
// }, 3000);

// // // // // infinite looping
// setInterval(() => {
//   for (let i = 0; i < 10; i++) {
//     setTimeout(() => {
//       input.focus();
//     }, 100);

//     // // //  setting timeout for blur
//     setTimeout(() => {
//       input.blur();
//     }, 200);
//   }
// });

// // // // // submitting the form and setting time
// setTimeout(() => {
//   form.submit();
//   console.log('form submitted');
// }, 2000);

// // // // submitting the form  and setting time
setTimeout(() => {
  form.reset();
  console.log('form reset');
}, 2000);
