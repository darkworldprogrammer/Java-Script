// //auto_reload
// setTimeout(() => {
//   location.reload();
// }, 3000);
// -------->>>>>>>>>>>
//  redirect to another file
// location.href = 'index2.html';
//  // go to next page
// history.forward();
//  // go to next page
// history.back();

//-------------->>>>>>>>>>
// //  go forward and backward
// history.go(1);
// history.go(-1);

// // ------------->>>>>
// // check height of your screen
// innerHeight
// innerWidth
// outerHeight
// outerWidth
// // ------------->>>>>
// open new tab
// open('https://www.google.co.in/')
// open('https://www.google.co.in/', 'Thedarkworld')
// open('index2.html')

//  // --------------->>>>>>>>>>
// close tab
// close()
// window.close()

//  // -------------->>>>>>>>>>
// // resize the windows tab
// window.open('https://www.youtube.com/', 'Devil', 'resizable');
// resizeTo(30, 50);
//   // ------------------------->>>>>>>>>>>>>
//  // move the tab windows
// moveTo(100,100)
//  // ----------->>>>>>>>>>>>>
// //  scroll
//  //  scroll in y direction from top to bottom
// window.scrollBy(0, 200);
//  //  scroll in y direction from bottom to top
// window.scrollBy(0, -200);
//  //------------------>>>>>>>>>>>>>>>>
//  // print
// print()