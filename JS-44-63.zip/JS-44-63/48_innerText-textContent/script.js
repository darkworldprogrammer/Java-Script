const h2 = document.querySelector(`#h2-1`);
h2.innerText;
const h22 = document.querySelector(`#h2-2`);
h22.textContent;
