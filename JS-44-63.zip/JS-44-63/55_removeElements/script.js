// // // ==============>>>>>>>
// //adding many images when no img available in html
// // //creating tags inside html using JS
let section = document.querySelector('#sec');
let HTML = ``;
for (let i = 1; i <= 100; i++) {
  HTML += `
      <div class="div">
        <img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${i}.png" alt="">
      <p class="para">${i}</p>
      </div>
    `;
  section.innerHTML = HTML;
}
// // // ===============>>>>>>>
// // // remove any child from parent
let div2 = section.childNodes[3];
div2.remove();

// // // ===============>>>>>>>
// // // permanently remove any child from parent
div2 = null;
