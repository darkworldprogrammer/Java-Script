const Name = document.querySelector('#name');
const userName = document.querySelector('#username');
const button = document.querySelector('#button');
const form = document.querySelector('form');

// // // Input Event
// userName.addEventListener('input', (e) => {
//   // console.log(e);
//   const inputValue = e.target.value;
//   // console.log(inputValue);
//   Name.textContent = inputValue;
// });

//  // // change Event(it will work after inputs)
// userName.addEventListener('change', (e) => {
//   const inputValue = e.target.value;
//   Name.textContent = inputValue;
// });

//  // // focus Event(it will work while focus)
// userName.addEventListener('focus', (e) => {
//   const inputValue = e.target.value;
//   Name.textContent = inputValue;
// });

//  // // blur Event(it will work while clicking outside)
// userName.addEventListener('blur', (e) => {
//   const inputValue = e.target.value;
//   Name.textContent = inputValue;
// });


// // // // for form
//  // // blur Event(it will work while clicking outside)
// form.addEventListener('click', (e) => {
//   console.log(e);
//   const inputValue = e.target.value;
//   Name.textContent = inputValue;
// });


form.addEventListener('submit', (e) => {
  console.log(e);
  const inputValue = e.target.value;
  Name.textContent = inputValue;
});

