const parent = document.querySelector('.parent');
const addCard = document.querySelector('.card-1');
const form = document.querySelector('form');
const input = document.querySelector('input');
const card = document.querySelector('.box');

// let n = 1;
// const cards = addCard.addEventListener('click', () => {
//   const newBox = document.createElement('div');
//   newBox.className = 'box';
//   newBox.innerText = n++;
//   parent.append(newBox);
// });

// // // // // applying remove function on new added cards
// let n = 1;
// const cards = addCard.addEventListener('click', () => {
//   const newBox = document.createElement('div');
//   newBox.className = 'box';
//   newBox.innerText = n++;
//   // Removing the new box
//   newBox.addEventListener('click', () => {
//     newBox.remove();
//   });
//   parent.append(newBox);
// });

// // // // applying new method to  remove new added cards
let n = 1;
const cards = addCard.addEventListener('click', () => {
  const newBox = document.createElement('div');
  newBox.className = 'box';
  newBox.innerText = n++;
  parent.append(newBox);
});
parent.addEventListener('click', (e) => {
  if (e.target != parent) {
    e.target.remove();
  }
});
