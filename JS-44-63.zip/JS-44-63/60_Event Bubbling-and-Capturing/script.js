const green = document.querySelector('.green');
const pink = document.querySelector('.pink');
const blue = document.querySelector('.blue');

// green.addEventListener('click', (e) => {
//   e.stopPropagation();
//   console.log('green');
// });
// pink.addEventListener('click', (e) => {
//   e.stopPropagation();
//   console.log('pink');
// });
// blue.addEventListener('click', (e) => {
//   e.stopPropagation();
//   console.log('blue');
// });

// // // click mandatory for first time only
green.addEventListener(
  'click',
  (e) => {
    e.stopPropagation();
    console.log('green');
  },
  { once: true }
);

