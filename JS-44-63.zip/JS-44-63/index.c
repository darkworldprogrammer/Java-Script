#include <stdio.h>
int main()
{
    int height, i, j, k;
    // Step 1: Set the height of the pyramid
    printf("Enter the height of the pyramid: ");
    scanf("%d", &height);
    // Step 2: Loop over each row
    for (i = 0; i < height; i++)
    {
        // Step 3: Print spaces for current row
        for (j = 0; j < height - i - 1; j++)
        {
            printf(" ");
        }
        // Step 4: Print stars for current row
        for (k = 0; k < 2 * i + 1; k++)
        {
            printf("*");
        }
        // Step 5: Move to the next line
        printf("\n");
    }
    return 0;
}
