const h1Color = document.querySelector('h1');
const h1BgColor = document.querySelector('h1');
h1Color.style.color = 'red';
h1BgColor.style.backgroundColor = '#1daffa';
// _---------------->>>>>
// _---------------->>>>>
const anchor = document.querySelectorAll('a');
const colorAdd = ['red', 'blue', 'pink', 'violet', 'green'];

// // adding color on all anchor tag
// for (let i = 0; i < anchor.length; i++) {
//   anchor[i].style.color = colorAdd[i];
// }
// //2nd method
anchor.forEach((color, i) => {
  //   color.style.color = colorAdd[i];
});

// // -------->>>>>>>>>>>>>>
// // -------->>>>>>>>>>>>>>

// // toUpperCase
// anchor[0].textContent = anchor[0].textContent.toUpperCase();
anchor.forEach((a) => {
  //   a.textContent = a.textContent.toUpperCase();
});
// // 2nd method
for (let upper of anchor) {
  //   upper.textContent = upper.textContent.toUpperCase();
  //   upper.style.color = 'red';
  //   upper.style.textDecoration = 'none';
  //   upper.style.fontWeight = 'bold';
  //   upper.style.fontSize = '25px';
  //   upper.style.fontFamily = 'monospace';
}
// // 3rd method
for (let upper of anchor) {
  //   upper.style.cssText = `
  //   background: red;
  //   font-family: monospace;
  //   text-decoration: none;
  //   font-size: 19px;
  //   border:2px solid cyan;
  //   text-transform: capitalize;
  // `;
}
// // 4th method
for (let upper of anchor) {
  // // creating class Name
  // upper.className = 'hyy'
  // upper.setAttribute('class', 'classCreatedByJS wavy-css');
    upper.classList.add('classCreatedByJS', 'wavy-css');
  // // // add and remove by toggle
//   upper.classList.toggle('classCreatedByJS');
  // // // remove the class Name
//   upper.classList.remove('classCreatedByJS');

}
