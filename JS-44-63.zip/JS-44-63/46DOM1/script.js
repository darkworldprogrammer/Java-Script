//  change html text using  ----------->>>>
// document.body.children[0].innerText = 'The Dark World';
// document.body.children[0].innerHTML = '<i>The Dark World</i>';
// document.body.children[0].textContent= 'Hello'

//  // ------------>>>>>>>>>>
//  change image of page by DOM manipulation
// function changeImg() {
//   document.body.children[4].src =
//     'https://img.freepik.com/premium-photo/wide-angle-shot-single-tree-growing-clouded-sky-sunset-surrounded-by-grass_181624-22807.jpg?semt=ais_hybrid';
// }
