// const span = document.querySelector('#span1');
// const parent = (span.parentElement.parentElement.parentElement.innerText =
//   'Hello');
// access siblings
const span3 = document.querySelector('#span2').nextElementSibling;
const span2 = document.querySelector('#span2').previousElementSibling;
const span1 = document.querySelector('#span2').nextSibling;
