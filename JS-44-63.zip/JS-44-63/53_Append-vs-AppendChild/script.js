const h3 = document.querySelector('h3');
const container = document.querySelector('section');
const child1 = document.querySelector('#card1');

// // //  cut the any elements and paste inside any parent
// container.appendChild(h3);
// // // duplicate the any elements
// container.append(h3.cloneNode(true));

// // // clone the card
const card1 = document.querySelector('#card1');
// container.append(card1.cloneNode(true));
// container.append(card1.cloneNode(true));

// // // create 50 cards using for loop
for (let i = 2; i <= 50; i++) {
  let newCards = card1.cloneNode();
  newCards.textContent = i;
  container.append(newCards);
  container.append('Himanshu');
}
