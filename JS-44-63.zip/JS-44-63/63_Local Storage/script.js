const nameInput = document.querySelector('.name-input');
const Name = document.querySelector('.head');
nameInput.addEventListener('click', (e) => {
  e.target.value = localStorage.userName;
});
