

let username = "Himanshu" 
let userIntro = "i am the devil."
let age = 22 
let amHappy = true

let all = username + " " +  userIntro + " " + age + " " + amHappy