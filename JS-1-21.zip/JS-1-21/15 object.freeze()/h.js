const userDetails = {
  userName: {
    fName: 'Himanshu',
    lName: 'Tiwari',
  },
  userAddress: {
    vill: 'Kharahana',
    city: 'Bhabua',
    State: 'Bihar',
  },
};

//adding new
// userDetails.userAddress.mobile_No = 9102405674;

//deleting new
// delete userDetails.userAddress.mobile_No;

// can't delete or add
// Object.seal(userDetails);

// cant add, delete or rename any data
Object.freeze(userDetails);
Object.freeze(userDetails.userName);
Object.freeze(userDetails.userAddress);
