const userName = prompt(`Enter your Name: `) || "The Dark World";
const userAge = parseInt(prompt(`Enter your Age: `)) || 22;

// console.log(`Name: ${userName}`);
// console.log(`Age: ${userAge}`);

if (userAge >= 5 && userAge <= 18) {
  console.log(`Name: ${userName}`);
  console.log(`Age: ${userAge}`);
  console.log(`${userName} is a School Student.`);
}
if (userAge <= 5) {
  console.log(`Name: ${userName}`);
  console.log(`Age: ${userAge}`);
  console.log(`${userName} is a Kid.`);
}
if (userAge >= 18 && userAge <= 24) {
  console.log(`Name: ${userName}`);
  console.log(`Age: ${userAge}`);
  console.log(`${userName} is a College Student.`);
}
if (userAge >= 24) {
  console.log(`Name: ${userName}`);
  console.log(`Age: ${userAge}`);
  console.log(`${userName} is a Working Professinal.`);
}
