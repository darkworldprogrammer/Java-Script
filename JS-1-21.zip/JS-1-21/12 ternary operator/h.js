// const a = true ? 'Devil' : 20;
// const b = false ? 'Devil' : 20;
// const c = 2 > 1 ? 'Himanshu' : 'Devil';
const gender = prompt('Enter your gender: ');
const userMessage = `You are a ${gender.toLowerCase() == 'f' ? 'Girl' : 'Boy'}`;
console.log(userMessage);


