const number = [1, 2, 3, 4, 5, 6, 7, 8, 9];
const oddNumber = [1, 3, 5, 7];
//removing elements from Starts
// number.shift();

//adding any value from starts
// number.unshift(0);

//adding many arrays
const animal = ['Bufallow', 'Ship', 'Horse', 'Tiger'];
const arrayConcat1 = animal.concat(number);
const arrayConcat2 = number.concat(oddNumber, animal);

//indexOf in array to find index of elements
number.indexOf(5);

//includes
// animal.includes('Ship');

//reverse
// animal.reverse();

//sort it includes all in one ascending(alphabetical) order
// animal.sort();

//slice() filtering only elements that user want but not affect on org array
// animal.slice(1, 3);
// output=['Horse', 'Ship']

//splice it affects on array and output from org array
// animal.splice(1, 2);
//adding another element on existing array
animal.splice(2, 1, 'Leperd');

const name = ['h', 'i', 'm', 'a'];
for (let i = 0; i < name.length; i++) {
  console.log(`Element at index ${i} is ${name[i]}`);
}
