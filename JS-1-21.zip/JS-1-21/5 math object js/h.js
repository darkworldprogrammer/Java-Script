//math function
//Math.sqrt(16)
//output=4

//for random value
//Math.floor(Math.random()*20)
//Math.floor(Math.random(2)*20)

// reactangle area
const a = +prompt("Enter the width of reactangle: ");
const b = +prompt("Enter the height of reactangle: ");
console.log("area of reactangle = " + a * b);

document.write(`Area of Reactangle: ${a * b}`);
