const Array = [
  ['Himanshu Tiwari', 75],
  ['Manish Tiwary', 90],
];

//Accessing one value eg. Manish Tiwary
Array[1][0];
//Accessing one value eg. Himanshu Tiwari
Array[0][0];

//Task to create patern of tic tac toe game
const newArray = [
  ['X', null, null],
  [null, null, 'O'],
  ['O', null, 'X'],
];
