// creating variable using let
let Fname='Himanshu'
let Sname='Tiwari'
let Age=21
let City='Bhopal'
// console.log(Fname+Sname+Age+City)

// overwriting the value of variable
Fname='Devil'
Sname=420 //but this is null value for string
let getDetail="My Name is "+Fname+" "+Sname+" and My Age are "+Age+" and i am from "+City;
// let a=undefined
// let b=null


//using const and can't overwrite
const dd=01
const mm=11
const yyyy=2024
const get= dd+" "+mm+" "+yyyy

//using variable(var) and can be declear anywhere
var a,b,c
a=2
b=3
c=a+b
