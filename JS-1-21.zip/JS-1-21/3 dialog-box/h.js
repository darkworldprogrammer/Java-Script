// alert("confirm! are you 18+?");
// const isConfirmed = confirm("would you like to proceed?");

const userInput = prompt("Please Enter your Name");
console.log(userInput);
