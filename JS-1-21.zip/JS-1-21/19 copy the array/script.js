const fruits = ['mango', 'apple', 'guava', 'banana'];
// fruits.push('dates');
console.log(fruits);
const user1 = {
  fName: 'Himanshu',
  lName: 'Tiwari',
};
// const user2.lName="pandey";

////   shallow copy

//  duplicate using another method of objects
const user2 = {};
Object.assign(user2, user1);
user2.lName = 'Pandey';

// OR
//  duplicate using another method
const user3 = { ...user1 };
// console.log(user1);
// console.log(user2);

// array duplicating and copying value
const newFruits = [...fruits];
newFruits.push(
  { Name: 'Devil', Age: '22', City: 'Bhopal' },
  { Name: 'Himanshu', Age: '22', City: 'Bhopal' }
);
// Object.assign(fruits, newFruits);
console.log(newFruits);
//new method
const addFruits = [].concat(fruits);

const userDetails1 = {
  name: 'Himanshu',
  age: 22,
  address: {
    Vill: 'Kharahana',
    City: 'Bhopal',
  },
  Subject: ['Math', 'Physics', 'Chemistry'],
};
const userDetails2 = { ...userDetails1 };

// ////deep copy
// const originalObject = {
//     name: 'John',
//     age: 30,
// address: {
//     city: 'New York',
//     country: 'USA'
// }
// };

// // Deep copy using JSON methods
// const deepCopyObject =
//     JSON.parse(JSON.stringify(originalObject));

// // Modifying the originalObject
// originalObject.name = 'Alice';
// originalObject.address.city = 'Los Angeles';

// console.log(originalObject);
// console.log(deepCopyObject);
