let num = 5;
// num = num + 5;
// num += 5;
// num -= 2;
let i;
// i * num;
for (i = 1; i <= 10; i++) {
  console.log(i*num);
}
