let userName = prompt(`Enter your Name: `);
let userAge = parseInt(prompt(`Enter your Age: `));

if (!userName) {
  userName = 'The Dark World';
  userAge = 22;
}

if (userAge >= 5 && userAge <= 18) {
  console.log(`Name: ${userName}`);
  console.log(`Age: ${userAge}`);
  console.log(`${userName} is a School Student.`);
} else if (userAge > 0 && userAge <= 5) {
  console.log(`Name: ${userName}`);
  console.log(`Age: ${userAge}`);
  console.log(`${userName} is a Kid.`);
} else if (userAge >= 18 && userAge <= 24) {
  console.log(`Name: ${userName}`);
  console.log(`Age: ${userAge}`);
  console.log(`${userName} is a College Student.`);
} else if (userAge >= 24 && userAge <= 45) {
  console.log(`Name: ${userName}`);
  console.log(`Age: ${userAge}`);
  console.log(`${userName} is a Working Professinal.`);
} else if (userAge > 45 && userAge < 120) {
  console.log(`${userName} is old and is reading newspaper.`);
} else if (userAge < 0) {
  console.log(`Name: ${userName}`);
  console.log(`Please Enter a valid age.`);
} else {
  console.log(`Name: ${userName}`);
  console.log(`${userName} is Immortal`);
}
