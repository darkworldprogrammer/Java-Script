//objects
const user1 = {
  firstName: 'Himanshu',
  lastName: 'Tiwari',
  age: 22,
  address: {
    city: 'Bhopal',
    pinCode: 462036,
    state: 'Madhya Pradesh',
  },
};

const user2 = {
  firstName: 'Manish',
  lastName: 'Tiwary',
  age: 25,
  city: 'Delhi',
};

const user3 = {
  firstName: 'Satish',
  lastName: 'Tiwari',
};
console.log(user3['firstName']);

//adding new value
const user4 = {
  firstName: 'Devil',
  lastName: 'Tiwary',
  age: 22,
  city: 'Bhopal',
};
user4.core = 'CSE';
user4['mName'] = 'Kumar';
