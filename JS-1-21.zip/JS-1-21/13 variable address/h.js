const fName = 'Himanshu';
const Age = '22';
const isGraduate = false;
