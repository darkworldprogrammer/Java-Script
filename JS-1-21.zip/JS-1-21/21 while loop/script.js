// let a = 1;
// // while(a=1,a<=100,a++){
// //   // console.log(a);
// // }
// while (a <= 100) {
//   console.log(a);
//   a++;
// }

// const friendsName = [
//   'Manish Tiwary',
//   'Satish Tiwari',
//   'Himanshu Tiwari',
//   'Shubham Mishra',
//   'Anushka Choubey',
// ];
// let i = 0;
// while (i <= friendsName.length) {
//   console.log(`${i + 1}. Programmer ${friendsName[i]}`);
//   i++;
// }

const users = [
  ['Himanshu', 22, 'Bhopal'],
  ['Manish', 26, 'Delhi'],
  ['Beauty', 24, 'Sasaram'],
];

let i=0;
let j=0;
while(i<users[j].length){
  console.log(users[i][j]);
  i++
}
