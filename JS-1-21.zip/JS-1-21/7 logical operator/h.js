//AND Conditions
const userAge = 28;
const isCollegeStudent = userAge >= 18 && userAge <= 28;
// console.log(isCollegeStudent);

//OR Conditions
const isSchoolStudent = userAge >= 4 && userAge <= 18;
const isStudent = isSchoolStudent || isCollegeStudent;

//NOT Conditions
const a = 0;
const b = 1;
const i = a && b;
