// const user1Age = "20";
// const user2Age = 30;
// if (user1Age == user2Age) {
//   console.log("true");
// }

//parseInt(user1Age) to change number from string

const user1Age = "20";
const user2Age = "30";
// if (user1Age != user2Age) {
//   console.log("true");
// }
//user1Age!=user2Age
//output is true