// const gender = 'male';
// switch (gender) {
//  case 'male':
//    console.log('it is male');
// }

//------------------

// const dayNumber = 3;

// switch (dayNumber) {
//  case 1:
//    console.log('today is Sunday');
//     break;
//  case 2:
//    console.log('today is Monday');
//     break;
//  case 3:
//    console.log('today is Tuesday');
//     break;
//  case 4:
//    console.log('today is Wednesday');
//     break;
//  case 5:
//    console.log('today is Thursday');
//     break;
//  case 6:
//    console.log('today is Friday');
//     break;
//  case 7:
//    console.log('today is Saturday');
//    break;
//  default:
//   console.log('Please Enter a Valid Day Number:');
// }

//------------------

// if (dayNumber == 1) {
// console.log('today is Monday');
// } else if (dayNumber == 2) {
// console.log('today is Tuesday');
// } else if (dayNumber == 3) {
// console.log('today is Wednesday');
// } else if (dayNumber == 4) {
// console.log('today is Thursday');
// } else if (dayNumber == 5) {
// console.log('today is Friday');
// } else if (dayNumber == 6) {
// console.log('today is Saturday');
// } else if (dayNumber == 1) {
// console.log('today is Sunday');
// }

//------------------

const userName = 'Devil';
const userAge = 22;

switch (true) {
  case userAge >= 5 && userAge <= 18:
    console.log(`Name: ${userName}`);
    console.log(`Age: ${userAge}`);
    console.log(`${userName} is a School Student.`);
    break;
  case userAge > 0 && userAge <= 5:
    console.log(`Name: ${userName}`);
    console.log(`Age: ${userAge}`);
    console.log(`${userName} is a Kid.`);
    break;
  case userAge >= 18 && userAge <= 24:
    console.log(`Name: ${userName}`);
    console.log(`Age: ${userAge}`);
    console.log(`${userName} is a College Student.`);
    break;
  case userAge >= 24 && userAge <= 45:
    console.log(`Name: ${userName}`);
    console.log(`Age: ${userAge}`);
    console.log(`${userName} is a Working Professinal.`);
    break;
  case userAge > 45 && userAge < 120:
    console.log(`Name: ${userName}`);
    console.log(`Age: ${userAge}`);
    console.log(`${userName} is old and is reading newspaper.`);
    break;
  case userAge > 120:
    console.log(`Name: ${userName}`);
    console.log(`${userName} is Immortal`);
    break;
  default:
    console.log(`Please Enter Valid Details.`);
}
