const fruitsList = ['Apple', 'Banana', 'Mango'];

//ACCES USING INDEX VALUE
fruitsList[2];

// update VALUE
fruitsList[2] = 'Grapes';

//adding new VALUE
fruitsList[3] = 'Dates';

// adding serial wise
fruitsList.push('pie');

//removing using INDEX
// ranbowColors.pop(1)

const userDetails = [
  'Himanshu Tiwari',
  '9102405674',
  { Name: 'Kharahana' },
  { Name: 'Nateya' },
];

//TASK
const ranbowColors = [
  'Violet',
  'Indigo',
  'Blue',
  'Green',
  'Yellow',
  'Orange',
  'Red',
];
console.log(ranbowColors);

//forcefully storing value of object in array
const newArray = [];
newArray.fName = 'Himanshu';
newArray.mName = 'Kumar';
newArray.lName = 'Tiwari';
