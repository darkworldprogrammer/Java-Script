//const message = "hello this is ur devil";
// find index message[3]
// find length message.length

//const extraSpaceMessage = "   Hello   ";
//extraSpaceMessage.trim();
//console.log(extraSpaceMessage);

//method with arguments----->

// to do any value uppercase message.toUpperCase()
//const capitalMessage = message.toUpperCase();
//console.log(capitalMessage);

//replace()
//const changeMessage = "Hello, This is Himanshu Tiwari";
// Example--> changeMessage.replace("Hello","Hi")
// changeMessage.replaceAll("H","h")

//concatination()
//const newMessage = " From Kaimur Bihar";
//const a = changeMessage.concat(newMessage);
//console.log(a);

//padStart()
const last4Digit = "1234";
// const maskedAccountNumber = last4Digit.padStart(16, "*");
// console.log(maskedAccountNumber);

//split()
// const b = "Hy Himanshu Tiwari";
// b.split(" ")

const concatenatedDetails = "Last 4 Digit of My Accunt no. is";
const acc = concatenatedDetails.concat(" ", last4Digit);
console.log(acc);

// using string template literal
const accountDetails = `Last 4 Digit of My Accunt no. is ${last4Digit.padStart(
  16,
  "*"
)}`;

const bankBalance = 500;
const fetchBankBalance = `I have ${bankBalance} in My Account.`;
